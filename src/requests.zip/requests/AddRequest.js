import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useSelector } from 'react-redux';

const DemandeForm = () => {
  const [titre, setTitre] = useState('');
  const [description, setDescription] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [type, setType] = useState('maladie');
  const [error, setError] = useState('');
  const userId = useSelector((state) => state.user.id); // ID utilisateur connecté

  useEffect(() => {
    if (!userId) {
      setError('Utilisateur non identifié.');
    }
  }, [userId]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!userId) {
      alert('Utilisateur non identifié, impossible de soumettre la demande.');
      return;
    }

    const newRequest = {
      title: titre,
      startDate,
      endDate,
      type,
      description,
      status: 'En attente',
      createdAt: new Date().toISOString(),
    };

    try {
      // Ajouter une nouvelle demande à l'utilisateur via l'API Mock
      const response = await axios.get(`https://670ed5b73e7151861655eaa3.mockapi.io/Stagiaire/${userId}`);
      const user = response.data;

      // Mise à jour des demandes
      const updatedRequests = [...(user.requests || []), newRequest];

      // Mise à jour de l'utilisateur avec les nouvelles demandes
      await axios.put(`https://670ed5b73e7151861655eaa3.mockapi.io/Stagiaire/${userId}`, {
        ...user,
        requests: updatedRequests,
      });

      alert('Demande ajoutée avec succès !');
      setTitre('');
      setDescription('');
      setStartDate('');
      setEndDate('');
    } catch (error) {
      console.error('Erreur lors de l\'ajout de la demande :', error);
      alert('Une erreur s\'est produite lors de la soumission de la demande.');
    }
  };

  return (
    <div>
      <h2>Ajouter une Demande</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="titre">Titre :</label>
          <input
            type="text"
            id="titre"
            value={titre}
            onChange={(e) => setTitre(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="description">Description :</label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          ></textarea>
        </div>
        <div>
          <label htmlFor="startDate">Date de début :</label>
          <input
            type="date"
            id="startDate"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="endDate">Date de fin :</label>
          <input
            type="date"
            id="endDate"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            required
          />
        </div>
        
        <button type="submit" disabled={!userId}>Soumettre</button>
      </form>
    </div>
  );
};

export default DemandeForm;
