import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import './MyRequests.css';

const MyRequests = () => {
  const [requests, setRequests] = useState([]);
  const [error, setError] = useState('');
  const { userId } = useParams();

  useEffect(() => {
    if (!userId) {
      setError('Utilisateur non identifié.');
      return;
    }

    // Appel à l'API pour récupérer les demandes de l'utilisateur
    axios
      .get(`http://localhost/ApiDemande/api.php?action=getUserRequests&user_id=${userId}`)
      .then((response) => {
        console.log("Réponse API:", response.data);
        if (response.data.success && response.data.requests.length > 0) {
          setRequests(response.data.requests);
        } else {
          setError('Aucune demande trouvée pour cet utilisateur.');
        }
      })
      .catch((error) => {
        console.error('Erreur lors de la récupération des demandes:', error);
        setError('Une erreur est survenue. Veuillez réessayer.');
      });
  }, [userId]);

  const handleCancelRequest = (requestId) => {
    if (window.confirm("Êtes-vous sûr de vouloir annuler cette demande ?")) {
      axios
        .post('http://localhost/ApiDemande/api.php', {
          action: 'cancelRequest',
          request_id: requestId,
        })
        .then((response) => {
          if (response.data.success) {
            setRequests(requests.filter((request) => request.id !== requestId));
            alert("Demande annulée avec succès !");
          } else {
            alert("Une erreur est survenue lors de l'annulation de la demande.");
          }
        })
        .catch((error) => {
          console.error('Erreur lors de l\'annulation de la demande:', error);
          alert('Une erreur est survenue. Veuillez réessayer.');
        });
    }
  };

  return (
    <div className="requests-container">
      <h2>Mes Demandes</h2>
      {error && <p className="error-message">{error}</p>}
      <div className="requests-list">
        {requests.length > 0 ? (
          requests.map((request) => (
            <div key={request.id} className="request-card">
              <h3>{request.titre}</h3>
              <p>{request.description}</p>
              <p className={`status ${request.statut.replace(' ', '-').toLowerCase()}`}>Statut: {request.statut}</p>
              <button
                className="cancel-button"
                onClick={() => handleCancelRequest(request.id)}
                disabled={request.statut === 'Annulée'}
              >
                Annuler la demande
              </button>
            </div>
          ))
        ) : (
          <p>Aucune demande trouvée.</p>
        )}
      </div>
    </div>
  );
};

export default MyRequests;
